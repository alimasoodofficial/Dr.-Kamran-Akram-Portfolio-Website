export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/free-resources", label: "Free Resources" },
  { href: "/projects", label: "Projects" },
  { href: "/consulting", label: "Consulting" },
  { href: "/gallery", label: "Gallery" },
  { href: "/academy", label: "Academy" },
  { href: "/newsletter", label: "Newsletter" },
];
