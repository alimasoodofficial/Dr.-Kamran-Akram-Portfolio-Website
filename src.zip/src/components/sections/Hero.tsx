import "../../app/globals.css";

export default function Hero() {
  return (
    <section className="text-center py-12 text-5xl ">
      <h1 className="font-heading text-5xl">Heading (DM Serif Display)</h1>
<p className="font-body font-light text-lg">Poppins Light (300)</p>
<p className="font-body font-bold text-lg">Poppins Bold (700)</p>
<p className="font-body font-black text-lg">Poppins Black (900)</p>

    </section>
  );
}
