export default function AcademyPage() {
  return <h1 className="text-3xl font-bold">Academy</h1>;
}