import Hero from "@/components/sections/Hero";
import Button from "@/components/ui/Button";


export default function HomePage() {
  return (
    <div>
      <Hero />
      <h2 className="text-4xl font-bold mt-8">I am Kamran Akram!</h2>
      <p>This is the HomePage page of my Next.js website.</p>
      <div className="space-x-4 p-6">
      {/* Primary button */}
      <Button className="bg-blue-600 text-white hover:bg-blue-700">
        Primary
      </Button>

      {/* Secondary button */}
      <Button className="bg-gray-200 text-gray-800 hover:bg-gray-300">
        Secondary
      </Button>

      {/* Danger button */}
      <Button className="bg-red-600 text-white hover:bg-red-700">
        Delete
      </Button>
    </div>

      
    </div>
  );
}
