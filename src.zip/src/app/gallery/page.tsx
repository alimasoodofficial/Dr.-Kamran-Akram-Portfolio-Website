export default function GalleryPage() {
  return <h1 className="text-3xl font-bold">Gallery</h1>;
}