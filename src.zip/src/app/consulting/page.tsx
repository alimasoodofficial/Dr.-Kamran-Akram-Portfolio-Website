export default function ConsultingPage() {
  return <h1 className="text-3xl font-bold">Consulting Services</h1>;
}