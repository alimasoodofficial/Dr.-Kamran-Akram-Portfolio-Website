export default function FreeResourcesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Free Resources</h1>
      <p>Explore ebooks, tools, and more.</p>
    </div>
  );
}