export default function EbooksPage() {
  return <h1 className="text-2xl">Ebooks Collection</h1>;
}