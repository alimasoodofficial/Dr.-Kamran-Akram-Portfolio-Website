export default function ToolsPage() {
  return <h1 className="text-2xl">Free Tools</h1>;
}